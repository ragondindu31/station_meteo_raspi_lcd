Images libres d'utilisation créés par d3stroy:
https://d3stroy.deviantart.com/art/SILq-Weather-Icons-356609017

